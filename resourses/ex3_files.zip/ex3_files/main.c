#include <stdio.h>
#include "pstring.h"

int main() {

	run_main();
	return 0;
}
